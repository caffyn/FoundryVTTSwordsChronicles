This is a Foundry VTT game system for Swords Chronicles. It is currently in an incomplete state, but is undergoing active development. 
This is based on the excellent Boilerplate system

Known issues:
1. Destiny Points are not automatically spent or gained when applying Qualities or Drawbacks using Compendium items. 
2. Sprint movement for drag purposes will not calculate correctly if using the ShowDragDistance module.

Install URL: 
https://github.com/caffyn/FoundryVTTSwordsChronicles/raw/main/system.json 
